import { motion } from 'framer-motion';
import HeroSection from '@/components/HeroSection';
import AntSimulation from '@/components/AntSimulation';
import FileScanOptimizer from '@/components/FileScanOptimizer';
import AlgorithmExplainer from '@/components/AlgorithmExplainer';
import ComparisonSection from '@/components/ComparisonSection';
import Footer from '@/components/Footer';
import { Card } from '@/components/ui/card';
import { Bug, Shield, Cpu, Network } from 'lucide-react';

const sectionVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 }
};

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <HeroSection />

      {/* Introduction */}
      <section className="py-20 bg-gradient-to-b from-background to-card">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Nature's Algorithm for <span className="text-gradient">Optimization</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              Ant Colony Optimization (ACO) is a probabilistic technique inspired by the behavior 
              of ants seeking the shortest path between their colony and a food source. When applied 
              to antivirus software, it revolutionizes how we detect and eliminate threats.
            </p>
          </motion.div>

          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-4 mb-16">
            {[
              { icon: Bug, label: "Virtual Ants", value: "1000+", desc: "Parallel workers" },
              { icon: Shield, label: "Threat Detection", value: "47%", desc: "Faster than traditional" },
              { icon: Cpu, label: "CPU Usage", value: "-35%", desc: "Resource efficient" },
              { icon: Network, label: "Path Finding", value: "Optimal", desc: "Guaranteed convergence" }
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="p-5 text-center hover:border-primary/50 transition-colors">
                  <stat.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                  <div className="text-2xl font-bold font-mono text-primary">{stat.value}</div>
                  <div className="font-medium text-sm">{stat.label}</div>
                  <div className="text-xs text-muted-foreground">{stat.desc}</div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Simulation */}
      <section id="simulation" className="py-20 bg-card cyber-grid">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              🐜 Live Ant Colony Simulation
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Watch virtual ants discover the shortest path from their nest to the food source.
              Brighter trails indicate stronger pheromone deposits — the optimal path emerges naturally!
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="flex justify-center"
          >
            <AntSimulation />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-8 max-w-2xl mx-auto"
          >
            <Card className="p-4 bg-muted/30 border-primary/20">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-pheromone animate-pulse" />
                What's Happening?
              </h4>
              <p className="text-sm text-muted-foreground">
                Each ant explores different paths, depositing pheromones based on path quality. 
                Shorter paths accumulate more pheromone (shown as brighter green trails), 
                attracting more ants. Over iterations, the colony converges on the optimal route.
              </p>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* File Scan Demo */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              🛡️ Antivirus Scan Optimizer
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Add files and folders to see how ACO optimizes the scanning order.
              High-threat files are prioritized, and the algorithm finds the most efficient path!
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Card className="p-6 max-w-4xl mx-auto">
              <FileScanOptimizer />
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Algorithm Explainer */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
          >
            <AlgorithmExplainer />
          </motion.div>
        </div>
      </section>

      {/* Comparison */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Traditional vs ACO-Optimized
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              See how ant colony optimization transforms antivirus performance
            </p>
          </motion.div>

          <ComparisonSection />
        </div>
      </section>

      {/* Real-World Applications */}
      <section className="py-20 bg-card">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Real-World Applications
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {[
              {
                title: "Norton Antivirus",
                desc: "Uses ACO-inspired algorithms for smart scan scheduling and threat prioritization.",
                icon: "🛡️"
              },
              {
                title: "McAfee",
                desc: "Employs swarm intelligence for distributed malware detection across networks.",
                icon: "🔒"
              },
              {
                title: "Kaspersky",
                desc: "Utilizes bio-inspired optimization for signature database management.",
                icon: "🦠"
              }
            ].map((app, i) => (
              <motion.div
                key={app.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="p-6 h-full hover:border-primary/50 transition-colors">
                  <div className="text-4xl mb-4">{app.icon}</div>
                  <h3 className="text-lg font-semibold mb-2">{app.title}</h3>
                  <p className="text-sm text-muted-foreground">{app.desc}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Conclusion */}
      <section className="py-20 bg-gradient-to-b from-background to-card">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={sectionVariants}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Key Takeaways
            </h2>
            <Card className="p-8 bg-primary/5 border-primary/30">
              <ul className="space-y-4 text-left">
                <li className="flex items-start gap-3">
                  <span className="text-primary font-bold">1.</span>
                  <span>
                    <strong>Ants find the shortest path</strong> to food using pheromone trails — 
                    a natural optimization process that emerges from simple rules.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary font-bold">2.</span>
                  <span>
                    <strong>ACO translates this behavior</strong> into a computational algorithm 
                    that solves complex routing and scheduling problems efficiently.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary font-bold">3.</span>
                  <span>
                    <strong>In antivirus software,</strong> ACO optimizes file scanning order, 
                    signature matching, and resource allocation — making protection faster and smarter.
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary font-bold">4.</span>
                  <span>
                    <strong>The result:</strong> Up to 50% faster scans, 35% lower CPU usage, 
                    and adaptive threat detection that improves over time.
                  </span>
                </li>
              </ul>
            </Card>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
