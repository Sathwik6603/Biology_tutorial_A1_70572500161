import { Bug, Github, ExternalLink } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Bug className="w-5 h-5 text-primary" />
            <span className="font-semibold">ACO Antivirus Optimizer</span>
          </div>
          
          <div className="text-sm text-muted-foreground text-center">
            Elements of Biology Presentation • B.Tech 1st Year
          </div>
          
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <a 
              href="https://en.wikipedia.org/wiki/Ant_colony_optimization_algorithms"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-primary transition-colors"
            >
              Learn More <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-border text-center text-xs text-muted-foreground">
          <p>
            Inspired by the collective intelligence of ant colonies. 
            This simulation demonstrates how biological systems can solve complex computational problems.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
