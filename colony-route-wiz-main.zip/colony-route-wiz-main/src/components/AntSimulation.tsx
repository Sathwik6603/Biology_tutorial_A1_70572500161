import { useEffect, useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw } from 'lucide-react';

interface Node {
  id: number;
  x: number;
  y: number;
  label: string;
  isFood?: boolean;
  isNest?: boolean;
}

interface Edge {
  from: number;
  to: number;
  pheromone: number;
  distance: number;
}

interface Ant {
  id: number;
  x: number;
  y: number;
  currentNode: number;
  path: number[];
  targetNode: number;
  progress: number;
  hasFood: boolean;
  color: string;
}

const AntSimulation = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const [isRunning, setIsRunning] = useState(false);
  const [iteration, setIteration] = useState(0);
  const [bestPath, setBestPath] = useState<number[]>([]);
  const [bestDistance, setBestDistance] = useState<number>(Infinity);

  const nodesRef = useRef<Node[]>([
    { id: 0, x: 80, y: 200, label: 'Nest', isNest: true },
    { id: 1, x: 180, y: 100, label: 'A' },
    { id: 2, x: 180, y: 300, label: 'B' },
    { id: 3, x: 300, y: 150, label: 'C' },
    { id: 4, x: 300, y: 250, label: 'D' },
    { id: 5, x: 420, y: 100, label: 'E' },
    { id: 6, x: 420, y: 300, label: 'F' },
    { id: 7, x: 520, y: 200, label: 'Food', isFood: true },
  ]);

  const edgesRef = useRef<Edge[]>([]);
  const antsRef = useRef<Ant[]>([]);

  const initializeEdges = useCallback(() => {
    const nodes = nodesRef.current;
    const edges: Edge[] = [];
    
    const connections = [
      [0, 1], [0, 2],
      [1, 3], [1, 5],
      [2, 4], [2, 6],
      [3, 4], [3, 5],
      [4, 6],
      [5, 7], [6, 7],
    ];

    connections.forEach(([from, to]) => {
      const dx = nodes[to].x - nodes[from].x;
      const dy = nodes[to].y - nodes[from].y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      edges.push({ from, to, pheromone: 1, distance });
      edges.push({ from: to, to: from, pheromone: 1, distance });
    });

    edgesRef.current = edges;
  }, []);

  const initializeAnts = useCallback(() => {
    const ants: Ant[] = [];
    for (let i = 0; i < 8; i++) {
      ants.push({
        id: i,
        x: nodesRef.current[0].x,
        y: nodesRef.current[0].y,
        currentNode: 0,
        path: [0],
        targetNode: 0,
        progress: 0,
        hasFood: false,
        color: `hsl(${30 + Math.random() * 20}, 70%, ${25 + Math.random() * 10}%)`,
      });
    }
    antsRef.current = ants;
  }, []);

  const getNeighbors = useCallback((nodeId: number) => {
    return edgesRef.current
      .filter(e => e.from === nodeId)
      .map(e => ({ nodeId: e.to, edge: e }));
  }, []);

  const selectNextNode = useCallback((ant: Ant) => {
    const neighbors = getNeighbors(ant.currentNode);
    const unvisited = neighbors.filter(n => !ant.path.includes(n.nodeId));
    
    if (unvisited.length === 0) {
      if (ant.currentNode === 7) return 7;
      return neighbors[Math.floor(Math.random() * neighbors.length)]?.nodeId ?? ant.currentNode;
    }

    const alpha = 1;
    const beta = 2;
    
    let total = 0;
    const probabilities = unvisited.map(n => {
      const pheromone = Math.pow(n.edge.pheromone, alpha);
      const heuristic = Math.pow(1 / n.edge.distance, beta);
      const prob = pheromone * heuristic;
      total += prob;
      return { nodeId: n.nodeId, prob };
    });

    const rand = Math.random() * total;
    let cumulative = 0;
    for (const p of probabilities) {
      cumulative += p.prob;
      if (rand <= cumulative) return p.nodeId;
    }

    return probabilities[probabilities.length - 1].nodeId;
  }, [getNeighbors]);

  const updatePheromones = useCallback(() => {
    const evaporationRate = 0.1;
    edgesRef.current.forEach(e => {
      e.pheromone *= (1 - evaporationRate);
      e.pheromone = Math.max(0.1, e.pheromone);
    });

    antsRef.current.forEach(ant => {
      if (ant.path.includes(7)) {
        let totalDistance = 0;
        for (let i = 0; i < ant.path.length - 1; i++) {
          const edge = edgesRef.current.find(
            e => e.from === ant.path[i] && e.to === ant.path[i + 1]
          );
          if (edge) totalDistance += edge.distance;
        }

        if (totalDistance < bestDistance) {
          setBestDistance(totalDistance);
          setBestPath([...ant.path]);
        }

        const deposit = 100 / totalDistance;
        for (let i = 0; i < ant.path.length - 1; i++) {
          const edge = edgesRef.current.find(
            e => e.from === ant.path[i] && e.to === ant.path[i + 1]
          );
          if (edge) edge.pheromone += deposit;
        }
      }
    });
  }, [bestDistance]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'hsl(220, 20%, 6%)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid
    ctx.strokeStyle = 'hsla(160, 30%, 20%, 0.2)';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw edges with pheromone intensity
    edgesRef.current.forEach(edge => {
      const fromNode = nodesRef.current[edge.from];
      const toNode = nodesRef.current[edge.to];
      
      const intensity = Math.min(edge.pheromone / 10, 1);
      ctx.strokeStyle = `hsla(160, 100%, 50%, ${0.1 + intensity * 0.7})`;
      ctx.lineWidth = 1 + intensity * 4;
      
      ctx.beginPath();
      ctx.moveTo(fromNode.x, fromNode.y);
      ctx.lineTo(toNode.x, toNode.y);
      ctx.stroke();

      // Glow effect for high pheromone
      if (intensity > 0.3) {
        ctx.shadowColor = 'hsl(160, 100%, 50%)';
        ctx.shadowBlur = intensity * 15;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
    });

    // Draw best path
    if (bestPath.length > 1) {
      ctx.strokeStyle = 'hsla(160, 100%, 60%, 0.8)';
      ctx.lineWidth = 3;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(nodesRef.current[bestPath[0]].x, nodesRef.current[bestPath[0]].y);
      for (let i = 1; i < bestPath.length; i++) {
        ctx.lineTo(nodesRef.current[bestPath[i]].x, nodesRef.current[bestPath[i]].y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw nodes
    nodesRef.current.forEach(node => {
      ctx.beginPath();
      
      if (node.isNest) {
        ctx.fillStyle = 'hsl(30, 60%, 35%)';
        ctx.arc(node.x, node.y, 22, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'hsl(30, 60%, 50%)';
        ctx.lineWidth = 2;
        ctx.stroke();
      } else if (node.isFood) {
        ctx.fillStyle = 'hsl(120, 70%, 35%)';
        ctx.arc(node.x, node.y, 22, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'hsl(120, 70%, 50%)';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.shadowColor = 'hsl(120, 70%, 50%)';
        ctx.shadowBlur = 10;
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else {
        ctx.fillStyle = 'hsl(220, 15%, 15%)';
        ctx.arc(node.x, node.y, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = 'hsl(160, 30%, 30%)';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      ctx.fillStyle = 'hsl(160, 60%, 95%)';
      ctx.font = 'bold 12px Inter';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(node.label, node.x, node.y);
    });

    // Draw ants
    antsRef.current.forEach(ant => {
      ctx.save();
      ctx.translate(ant.x, ant.y);
      
      // Ant body
      ctx.fillStyle = ant.color;
      
      // Head
      ctx.beginPath();
      ctx.ellipse(6, 0, 4, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Thorax
      ctx.beginPath();
      ctx.ellipse(0, 0, 5, 4, 0, 0, Math.PI * 2);
      ctx.fill();
      
      // Abdomen
      ctx.beginPath();
      ctx.ellipse(-8, 0, 6, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Antennae
      ctx.strokeStyle = ant.color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(8, -2);
      ctx.lineTo(12, -6);
      ctx.moveTo(8, 2);
      ctx.lineTo(12, 6);
      ctx.stroke();

      // Legs
      ctx.beginPath();
      ctx.moveTo(-2, -4);
      ctx.lineTo(-4, -10);
      ctx.moveTo(2, -4);
      ctx.lineTo(4, -10);
      ctx.moveTo(-2, 4);
      ctx.lineTo(-4, 10);
      ctx.moveTo(2, 4);
      ctx.lineTo(4, 10);
      ctx.stroke();

      // Food indicator
      if (ant.hasFood) {
        ctx.fillStyle = 'hsl(120, 70%, 50%)';
        ctx.beginPath();
        ctx.arc(10, 0, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });
  }, [bestPath]);

  const animate = useCallback(() => {
    antsRef.current.forEach(ant => {
      if (ant.progress >= 1) {
        ant.currentNode = ant.targetNode;
        ant.path.push(ant.currentNode);
        ant.progress = 0;

        if (ant.currentNode === 7) {
          ant.hasFood = true;
        }

        if (ant.hasFood && ant.currentNode === 0) {
          updatePheromones();
          ant.path = [0];
          ant.hasFood = false;
          setIteration(prev => prev + 1);
        }

        const nextNode = selectNextNode(ant);
        ant.targetNode = nextNode;
      }

      const fromNode = nodesRef.current[ant.currentNode];
      const toNode = nodesRef.current[ant.targetNode];
      
      ant.progress += 0.02;
      ant.x = fromNode.x + (toNode.x - fromNode.x) * ant.progress;
      ant.y = fromNode.y + (toNode.y - fromNode.y) * ant.progress;
    });

    draw();
    animationRef.current = requestAnimationFrame(animate);
  }, [draw, selectNextNode, updatePheromones]);

  const startSimulation = () => {
    setIsRunning(true);
    animationRef.current = requestAnimationFrame(animate);
  };

  const pauseSimulation = () => {
    setIsRunning(false);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  };

  const resetSimulation = () => {
    pauseSimulation();
    initializeEdges();
    initializeAnts();
    setIteration(0);
    setBestPath([]);
    setBestDistance(Infinity);
    draw();
  };

  useEffect(() => {
    initializeEdges();
    initializeAnts();
    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [initializeEdges, initializeAnts, draw]);

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={600}
        height={400}
        className="rounded-xl border border-border bg-background"
      />
      
      <div className="absolute bottom-4 left-4 flex gap-2">
        <Button
          onClick={isRunning ? pauseSimulation : startSimulation}
          size="sm"
          className="gap-2"
        >
          {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          {isRunning ? 'Pause' : 'Start'}
        </Button>
        <Button onClick={resetSimulation} size="sm" variant="outline" className="gap-2">
          <RotateCcw className="w-4 h-4" />
          Reset
        </Button>
      </div>

      <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 border border-border">
        <div className="text-xs text-muted-foreground">Iterations</div>
        <div className="text-xl font-bold text-primary font-mono">{iteration}</div>
        {bestDistance < Infinity && (
          <>
            <div className="text-xs text-muted-foreground mt-2">Best Path</div>
            <div className="text-sm font-mono text-pheromone">
              {bestPath.map(n => nodesRef.current[n].label).join(' → ')}
            </div>
          </>
        )}
      </div>

      <motion.div
        className="absolute top-4 left-4 flex items-center gap-2 bg-card/90 backdrop-blur-sm rounded-lg px-3 py-2 border border-border"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
      >
        <div className="w-3 h-3 rounded-full bg-pheromone animate-pulse-glow" />
        <span className="text-xs text-muted-foreground">Pheromone Trail Intensity</span>
      </motion.div>
    </div>
  );
};

export default AntSimulation;
