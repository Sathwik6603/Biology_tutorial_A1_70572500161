import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { 
  Bug, 
  Footprints, 
  TrendingUp, 
  Repeat, 
  Shield, 
  Zap,
  Database,
  FileSearch
} from 'lucide-react';

const steps = [
  {
    icon: Bug,
    title: "Ants Explore",
    description: "Multiple virtual ants start from the nest (antivirus engine) and explore different paths through the file system.",
    color: "text-warning"
  },
  {
    icon: Footprints,
    title: "Pheromone Deposit",
    description: "Each ant deposits pheromones on the paths it takes. Shorter paths and higher-threat files get more pheromone.",
    color: "text-primary"
  },
  {
    icon: TrendingUp,
    title: "Path Reinforcement",
    description: "Paths with more pheromone attract more ants. Over time, the optimal scanning order emerges naturally.",
    color: "text-pheromone"
  },
  {
    icon: Repeat,
    title: "Evaporation & Adaptation",
    description: "Pheromones evaporate over time, preventing stagnation and allowing the algorithm to adapt to new threats.",
    color: "text-cyber"
  }
];

const antivirusApplications = [
  {
    icon: FileSearch,
    title: "Smart Scan Ordering",
    description: "ACO determines the optimal order to scan files, prioritizing high-risk areas like downloads and temp folders first."
  },
  {
    icon: Database,
    title: "Signature Matching",
    description: "Optimizes the order of virus signature comparisons, checking most likely matches first to speed up detection."
  },
  {
    icon: Shield,
    title: "Resource Allocation",
    description: "Distributes scanning resources efficiently across multiple cores, reducing CPU overhead during scans."
  },
  {
    icon: Zap,
    title: "Real-time Protection",
    description: "Continuously adapts scanning priorities based on user behavior and emerging threat patterns."
  }
];

const AlgorithmExplainer = () => {
  return (
    <div className="space-y-12">
      {/* Algorithm Steps */}
      <div>
        <h3 className="text-2xl font-bold mb-6 text-center">How Ant Colony Optimization Works</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-5 h-full hover:border-primary/50 transition-colors group">
                <div className="flex items-center gap-3 mb-3">
                  <div className={`p-2 rounded-lg bg-muted group-hover:bg-primary/20 transition-colors`}>
                    <step.icon className={`w-6 h-6 ${step.color}`} />
                  </div>
                  <span className="text-xs font-mono text-muted-foreground">
                    Step {index + 1}
                  </span>
                </div>
                <h4 className="font-semibold mb-2">{step.title}</h4>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Antivirus Applications */}
      <div>
        <h3 className="text-2xl font-bold mb-6 text-center">Applications in Antivirus Software</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {antivirusApplications.map((app, index) => (
            <motion.div
              key={app.title}
              initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-5 h-full border-border hover:border-primary/30 transition-all hover:shadow-lg hover:shadow-primary/5">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20">
                    <app.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">{app.title}</h4>
                    <p className="text-sm text-muted-foreground">{app.description}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Mathematical Foundation */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <Card className="p-6 bg-muted/30">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <span className="text-primary">∑</span> Mathematical Foundation
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2 font-mono text-sm text-primary">Probability Formula</h4>
              <div className="bg-background rounded-lg p-4 font-mono text-sm border border-border">
                <div className="text-center">
                  P<sub>ij</sub> = (τ<sub>ij</sub><sup>α</sup> × η<sub>ij</sub><sup>β</sup>) / Σ(τ<sub>ik</sub><sup>α</sup> × η<sub>ik</sub><sup>β</sup>)
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Where τ = pheromone level, η = heuristic (1/distance), α and β are parameters
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 font-mono text-sm text-primary">Pheromone Update</h4>
              <div className="bg-background rounded-lg p-4 font-mono text-sm border border-border">
                <div className="text-center">
                  τ<sub>ij</sub> ← (1-ρ)τ<sub>ij</sub> + Δτ<sub>ij</sub>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Where ρ = evaporation rate, Δτ = deposited pheromone based on solution quality
              </p>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default AlgorithmExplainer;
