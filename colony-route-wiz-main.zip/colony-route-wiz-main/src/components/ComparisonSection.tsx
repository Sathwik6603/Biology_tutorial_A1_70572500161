import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Check, X, ArrowRight } from 'lucide-react';

const ComparisonSection = () => {
  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Traditional Approach */}
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        <Card className="p-6 h-full border-destructive/30 bg-destructive/5">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <X className="w-6 h-6 text-destructive" />
            Traditional Antivirus Scanning
          </h3>
          
          <ul className="space-y-3">
            {[
              "Sequential file scanning from A to Z",
              "No prioritization of high-risk files",
              "Fixed signature matching order",
              "High CPU usage during full scans",
              "Slow adaptation to new threat patterns",
              "Resource-intensive background protection"
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="text-destructive mt-0.5">•</span>
                {item}
              </li>
            ))}
          </ul>

          <div className="mt-6 pt-4 border-t border-destructive/20">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Efficiency Score</span>
              <span className="font-mono text-destructive">~45%</span>
            </div>
            <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full w-[45%] bg-destructive/70 rounded-full" />
            </div>
          </div>
        </Card>
      </motion.div>

      {/* ACO Optimized */}
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        <Card className="p-6 h-full border-primary/30 bg-primary/5 glow-box">
          <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
            <Check className="w-6 h-6 text-primary" />
            ACO-Optimized Scanning
          </h3>
          
          <ul className="space-y-3">
            {[
              "Intelligent path finding through file system",
              "High-threat files scanned first",
              "Dynamic signature matching optimization",
              "Efficient resource distribution",
              "Self-adapting to emerging threats",
              "Lightweight real-time protection"
            ].map((item, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                {item}
              </li>
            ))}
          </ul>

          <div className="mt-6 pt-4 border-t border-primary/20">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Efficiency Score</span>
              <span className="font-mono text-primary">~92%</span>
            </div>
            <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-gradient-to-r from-primary to-pheromone rounded-full"
                initial={{ width: 0 }}
                whileInView={{ width: '92%' }}
                viewport={{ once: true }}
                transition={{ delay: 0.3, duration: 1 }}
              />
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Bottom Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="lg:col-span-2"
      >
        <Card className="p-6 bg-muted/30">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <h4 className="font-semibold mb-1">The Key Insight</h4>
              <p className="text-sm text-muted-foreground max-w-md">
                Just as ants collectively find the shortest path to food through pheromone trails, 
                ACO finds the optimal scanning path through your file system.
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-muted-foreground">100%</div>
                <div className="text-xs text-muted-foreground">Coverage</div>
              </div>
              <ArrowRight className="w-5 h-5 text-primary" />
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">50%</div>
                <div className="text-xs text-primary">Faster</div>
              </div>
              <ArrowRight className="w-5 h-5 text-primary" />
              <div className="text-center">
                <div className="text-2xl font-bold text-success">30%</div>
                <div className="text-xs text-success">Less CPU</div>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
};

export default ComparisonSection;
