import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronDown, Bug, Shield, Zap } from 'lucide-react';
import { useEffect, useState, useRef } from 'react';

interface AntParticle {
  id: number;
  x: number;
  y: number;
  angle: number;
  speed: number;
  trail: { x: number; y: number }[];
}

const HeroSection = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const antsRef = useRef<AntParticle[]>([]);
  const animationRef = useRef<number>();

  useEffect(() => {
    const updateDimensions = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  useEffect(() => {
    if (!dimensions.width) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Initialize ants
    antsRef.current = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * dimensions.width,
      y: Math.random() * dimensions.height,
      angle: Math.random() * Math.PI * 2,
      speed: 1 + Math.random() * 1.5,
      trail: []
    }));

    const animate = () => {
      ctx.fillStyle = 'rgba(11, 14, 18, 0.1)';
      ctx.fillRect(0, 0, dimensions.width, dimensions.height);

      antsRef.current.forEach(ant => {
        // Update position
        ant.angle += (Math.random() - 0.5) * 0.3;
        ant.x += Math.cos(ant.angle) * ant.speed;
        ant.y += Math.sin(ant.angle) * ant.speed;

        // Wrap around edges
        if (ant.x < 0) ant.x = dimensions.width;
        if (ant.x > dimensions.width) ant.x = 0;
        if (ant.y < 0) ant.y = dimensions.height;
        if (ant.y > dimensions.height) ant.y = 0;

        // Update trail
        ant.trail.push({ x: ant.x, y: ant.y });
        if (ant.trail.length > 30) ant.trail.shift();

        // Draw trail (pheromone)
        if (ant.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(ant.trail[0].x, ant.trail[0].y);
          
          for (let i = 1; i < ant.trail.length; i++) {
            const alpha = i / ant.trail.length * 0.4;
            ctx.strokeStyle = `hsla(160, 100%, 50%, ${alpha})`;
            ctx.lineWidth = 2;
            ctx.lineTo(ant.trail[i].x, ant.trail[i].y);
          }
          ctx.stroke();
        }

        // Draw ant
        ctx.save();
        ctx.translate(ant.x, ant.y);
        ctx.rotate(ant.angle);
        
        ctx.fillStyle = 'hsl(30, 60%, 30%)';
        ctx.beginPath();
        ctx.ellipse(0, 0, 6, 4, 0, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.beginPath();
        ctx.ellipse(6, 0, 4, 3, 0, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.restore();
      });

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [dimensions]);

  const scrollToContent = () => {
    document.getElementById('simulation')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Canvas */}
      <canvas
        ref={canvasRef}
        width={dimensions.width}
        height={dimensions.height}
        className="absolute inset-0 z-0"
      />

      {/* Gradient Overlay */}
      <div className="absolute inset-0 gradient-hero z-10" />

      {/* Content */}
      <div className="relative z-20 container mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 mb-8"
          >
            <Bug className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Bio-Inspired Computing</span>
          </motion.div>

          {/* Title */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            <span className="text-gradient glow-text">Ant Colony</span>
            <br />
            <span className="text-foreground">Algorithm</span>
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-muted-foreground mb-4 max-w-2xl mx-auto">
            Optimizing Antivirus Software Through Nature's Intelligence
          </p>
          
          <p className="text-sm text-muted-foreground mb-8 max-w-xl mx-auto">
            Discover how ants find the shortest path to food and how this behavior 
            revolutionizes malware detection and system scanning
          </p>

          {/* Feature Pills */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap justify-center gap-3 mb-10"
          >
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-muted/50 border border-border">
              <Zap className="w-4 h-4 text-warning" />
              <span className="text-sm">Faster Scans</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-muted/50 border border-border">
              <Shield className="w-4 h-4 text-success" />
              <span className="text-sm">Smarter Detection</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-muted/50 border border-border">
              <Bug className="w-4 h-4 text-primary" />
              <span className="text-sm">Swarm Intelligence</span>
            </div>
          </motion.div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            <Button
              onClick={scrollToContent}
              size="lg"
              className="group gap-2 text-lg px-8"
            >
              Explore Simulation
              <ChevronDown className="w-5 h-5 group-hover:translate-y-1 transition-transform" />
            </Button>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <div className="w-6 h-10 rounded-full border-2 border-primary/50 flex justify-center pt-2">
          <div className="w-1 h-3 rounded-full bg-primary animate-pulse-glow" />
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
