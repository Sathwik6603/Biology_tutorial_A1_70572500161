import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { 
  Folder, 
  FileText, 
  Plus, 
  Trash2, 
  Play, 
  Shield, 
  Bug,
  Zap,
  Clock
} from 'lucide-react';

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size: number;
  threatLevel: 'safe' | 'suspicious' | 'dangerous';
  scanned: boolean;
  x?: number;
  y?: number;
}

interface ScanResult {
  traditional: { time: number; order: string[] };
  aco: { time: number; order: string[] };
}

const defaultFiles: FileNode[] = [
  { id: '1', name: 'System32', type: 'folder', size: 1500, threatLevel: 'suspicious', scanned: false },
  { id: '2', name: 'startup.exe', type: 'file', size: 50, threatLevel: 'dangerous', scanned: false },
  { id: '3', name: 'config.sys', type: 'file', size: 10, threatLevel: 'safe', scanned: false },
  { id: '4', name: 'Downloads', type: 'folder', size: 2000, threatLevel: 'suspicious', scanned: false },
  { id: '5', name: 'browser_ext.dll', type: 'file', size: 100, threatLevel: 'dangerous', scanned: false },
  { id: '6', name: 'Documents', type: 'folder', size: 500, threatLevel: 'safe', scanned: false },
  { id: '7', name: 'temp_cache', type: 'folder', size: 800, threatLevel: 'suspicious', scanned: false },
  { id: '8', name: 'user_data.db', type: 'file', size: 200, threatLevel: 'safe', scanned: false },
];

const FileScanOptimizer = () => {
  const [files, setFiles] = useState<FileNode[]>(defaultFiles);
  const [newFileName, setNewFileName] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanMode, setScanMode] = useState<'idle' | 'traditional' | 'aco'>('idle');
  const [currentScanIndex, setCurrentScanIndex] = useState(-1);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanOrder, setScanOrder] = useState<string[]>([]);
  const scanTimeoutRef = useRef<NodeJS.Timeout>();

  const getThreatScore = (file: FileNode): number => {
    let score = 0;
    if (file.threatLevel === 'dangerous') score += 100;
    else if (file.threatLevel === 'suspicious') score += 50;
    else score += 10;
    
    score += file.size / 100;
    if (file.type === 'file' && file.name.endsWith('.exe')) score += 30;
    if (file.type === 'file' && file.name.endsWith('.dll')) score += 25;
    
    return score;
  };

  const runACOOptimization = useCallback(() => {
    const filesCopy = [...files];
    const n = filesCopy.length;
    const pheromones: number[][] = Array(n).fill(null).map(() => Array(n).fill(1));
    const threatScores = filesCopy.map(getThreatScore);
    
    let bestOrder: number[] = [];
    let bestScore = -Infinity;
    
    const numAnts = 10;
    const numIterations = 20;
    const alpha = 1;
    const beta = 2;
    const evaporation = 0.5;
    
    for (let iter = 0; iter < numIterations; iter++) {
      for (let ant = 0; ant < numAnts; ant++) {
        const visited: number[] = [];
        const unvisited = Array.from({ length: n }, (_, i) => i);
        
        while (unvisited.length > 0) {
          let probabilities: number[] = [];
          let total = 0;
          
          for (const next of unvisited) {
            const lastVisited = visited.length > 0 ? visited[visited.length - 1] : 0;
            const pheromone = Math.pow(pheromones[lastVisited][next], alpha);
            const heuristic = Math.pow(threatScores[next], beta);
            const prob = pheromone * heuristic;
            probabilities.push(prob);
            total += prob;
          }
          
          probabilities = probabilities.map(p => p / total);
          
          let rand = Math.random();
          let selectedIdx = 0;
          for (let i = 0; i < probabilities.length; i++) {
            rand -= probabilities[i];
            if (rand <= 0) {
              selectedIdx = i;
              break;
            }
          }
          
          visited.push(unvisited[selectedIdx]);
          unvisited.splice(selectedIdx, 1);
        }
        
        let pathScore = 0;
        for (let i = 0; i < visited.length; i++) {
          pathScore += threatScores[visited[i]] * (n - i);
        }
        
        if (pathScore > bestScore) {
          bestScore = pathScore;
          bestOrder = [...visited];
        }
        
        for (let i = 0; i < visited.length - 1; i++) {
          pheromones[visited[i]][visited[i + 1]] += pathScore / 1000;
        }
      }
      
      for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
          pheromones[i][j] *= (1 - evaporation);
          pheromones[i][j] = Math.max(0.1, pheromones[i][j]);
        }
      }
    }
    
    return bestOrder.map(i => filesCopy[i].id);
  }, [files]);

  const runTraditionalScan = useCallback(() => {
    return [...files].map(f => f.id);
  }, [files]);

  const simulateScan = useCallback((order: string[], mode: 'traditional' | 'aco') => {
    setIsScanning(true);
    setScanMode(mode);
    setScanOrder(order);
    setCurrentScanIndex(0);

    let index = 0;
    const scanNext = () => {
      if (index < order.length) {
        setCurrentScanIndex(index);
        setFiles(prev => prev.map(f => 
          f.id === order[index] ? { ...f, scanned: true } : f
        ));
        index++;
        scanTimeoutRef.current = setTimeout(scanNext, mode === 'traditional' ? 400 : 250);
      } else {
        setIsScanning(false);
        setCurrentScanIndex(-1);
      }
    };
    scanNext();
  }, []);

  const startComparison = () => {
    setFiles(prev => prev.map(f => ({ ...f, scanned: false })));
    setScanResult(null);
    
    const traditionalOrder = runTraditionalScan();
    const acoOrder = runACOOptimization();
    
    const traditionalTime = files.reduce((acc, f) => acc + f.size, 0) * 0.8;
    
    let acoTime = 0;
    const sortedFiles = acoOrder.map(id => files.find(f => f.id === id)!);
    sortedFiles.forEach((f, i) => {
      acoTime += f.size * (0.3 + (i * 0.05));
    });
    
    setScanResult({
      traditional: { time: Math.round(traditionalTime), order: traditionalOrder },
      aco: { time: Math.round(acoTime), order: acoOrder }
    });
    
    simulateScan(acoOrder, 'aco');
  };

  const addFile = () => {
    if (!newFileName.trim()) return;
    
    const threatLevels: ('safe' | 'suspicious' | 'dangerous')[] = ['safe', 'suspicious', 'dangerous'];
    const newFile: FileNode = {
      id: Date.now().toString(),
      name: newFileName,
      type: newFileName.includes('.') ? 'file' : 'folder',
      size: Math.floor(Math.random() * 500) + 50,
      threatLevel: threatLevels[Math.floor(Math.random() * 3)],
      scanned: false
    };
    
    setFiles(prev => [...prev, newFile]);
    setNewFileName('');
  };

  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  useEffect(() => {
    return () => {
      if (scanTimeoutRef.current) {
        clearTimeout(scanTimeoutRef.current);
      }
    };
  }, []);

  const getThreatColor = (level: FileNode['threatLevel']) => {
    switch (level) {
      case 'dangerous': return 'text-danger';
      case 'suspicious': return 'text-warning';
      default: return 'text-success';
    }
  };

  const getThreatBg = (level: FileNode['threatLevel']) => {
    switch (level) {
      case 'dangerous': return 'bg-danger/20 border-danger/50';
      case 'suspicious': return 'bg-warning/20 border-warning/50';
      default: return 'bg-success/20 border-success/50';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-3">
        <Input
          placeholder="Add file or folder (e.g., malware.exe)"
          value={newFileName}
          onChange={(e) => setNewFileName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addFile()}
          className="flex-1"
          disabled={isScanning}
        />
        <Button onClick={addFile} disabled={isScanning || !newFileName.trim()}>
          <Plus className="w-4 h-4 mr-2" />
          Add
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[300px] overflow-y-auto pr-2">
        <AnimatePresence mode="popLayout">
          {files.map((file, index) => (
            <motion.div
              key={file.id}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ 
                opacity: 1, 
                scale: 1,
                boxShadow: scanOrder[currentScanIndex] === file.id 
                  ? '0 0 20px hsl(160, 100%, 50%)' 
                  : 'none'
              }}
              exit={{ opacity: 0, scale: 0.8 }}
              className={`relative p-3 rounded-lg border ${getThreatBg(file.threatLevel)} 
                ${file.scanned ? 'ring-2 ring-pheromone/50' : ''}`}
            >
              <button
                onClick={() => removeFile(file.id)}
                className="absolute -top-2 -right-2 p-1 bg-destructive rounded-full opacity-0 hover:opacity-100 transition-opacity"
                disabled={isScanning}
              >
                <Trash2 className="w-3 h-3" />
              </button>
              
              <div className="flex items-center gap-2 mb-2">
                {file.type === 'folder' ? (
                  <Folder className={`w-5 h-5 ${getThreatColor(file.threatLevel)}`} />
                ) : (
                  <FileText className={`w-5 h-5 ${getThreatColor(file.threatLevel)}`} />
                )}
                {file.scanned && (
                  <Shield className="w-4 h-4 text-pheromone" />
                )}
              </div>
              
              <div className="text-xs font-mono truncate" title={file.name}>
                {file.name}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {file.size} KB
              </div>
              
              {file.threatLevel === 'dangerous' && (
                <Bug className="absolute bottom-2 right-2 w-4 h-4 text-danger animate-pulse" />
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="flex justify-center">
        <Button 
          onClick={startComparison} 
          disabled={isScanning || files.length < 2}
          size="lg"
          className="gap-2"
        >
          <Play className="w-5 h-5" />
          Run ACO Scan Optimization
        </Button>
      </div>

      {scanResult && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid md:grid-cols-2 gap-4"
        >
          <Card className="p-4 border-muted">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="w-5 h-5 text-muted-foreground" />
              <h4 className="font-semibold">Traditional Scan</h4>
            </div>
            <div className="text-3xl font-bold font-mono text-muted-foreground">
              {scanResult.traditional.time}ms
            </div>
            <div className="text-xs text-muted-foreground mt-2">
              Sequential scan order
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {scanResult.traditional.order.slice(0, 5).map(id => {
                const file = files.find(f => f.id === id);
                return file && (
                  <span key={id} className="text-xs px-2 py-1 bg-muted rounded">
                    {file.name.slice(0, 8)}
                  </span>
                );
              })}
              {scanResult.traditional.order.length > 5 && (
                <span className="text-xs px-2 py-1 text-muted-foreground">
                  +{scanResult.traditional.order.length - 5} more
                </span>
              )}
            </div>
          </Card>

          <Card className="p-4 border-primary/50 glow-box">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-5 h-5 text-primary" />
              <h4 className="font-semibold text-primary">ACO Optimized</h4>
            </div>
            <div className="text-3xl font-bold font-mono text-primary">
              {scanResult.aco.time}ms
            </div>
            <div className="text-xs text-pheromone mt-2">
              {Math.round((1 - scanResult.aco.time / scanResult.traditional.time) * 100)}% faster • Threats first
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {scanResult.aco.order.slice(0, 5).map(id => {
                const file = files.find(f => f.id === id);
                return file && (
                  <span key={id} className={`text-xs px-2 py-1 rounded ${getThreatBg(file.threatLevel)}`}>
                    {file.name.slice(0, 8)}
                  </span>
                );
              })}
              {scanResult.aco.order.length > 5 && (
                <span className="text-xs px-2 py-1 text-muted-foreground">
                  +{scanResult.aco.order.length - 5} more
                </span>
              )}
            </div>
          </Card>
        </motion.div>
      )}
    </div>
  );
};

export default FileScanOptimizer;
